﻿using HMS_MVC.Models;
using System;
using System.Collections.Generic;

namespace HMS_MVC.Models
{
    public partial class Role
    {
        public int RoleId { get; set; }

        public string RoleNm { get; set; } = null!;

        public virtual ICollection<Master> Masters { get; set; } = new List<Master>();
    }
}

