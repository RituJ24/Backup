﻿using System;
using System.Collections.Generic;
namespace HMS_MVC.Models
{
    public partial class DiseaseCategory
    {
        public string DisezCatId { get; set; } = null!;

        public string? DisezCatNm { get; set; }

        public virtual ICollection<Allergy> Allergies { get; set; } = new List<Allergy>();

        public virtual ICollection<Diagnosis> Diagnoses { get; set; } = new List<Diagnosis>();

        public virtual ICollection<Master> Masters { get; set; } = new List<Master>();
    }

}

