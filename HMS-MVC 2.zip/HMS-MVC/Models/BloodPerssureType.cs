﻿using System;
using System.Collections.Generic;

namespace HMS_MVC.Models
{
    public partial class BloodPerssureType
    {
        public string BpId { get; set; } = null!;

        public string? BpType { get; set; }

        public virtual ICollection<PatientVisit> PatientVisits { get; set; } = new List<PatientVisit>();
    }

}
