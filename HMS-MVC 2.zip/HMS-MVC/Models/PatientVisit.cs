﻿using System;
using System.Collections.Generic;

namespace HMS_MVC.Models
{
    public partial class PatientVisit
    {
        public string VisitId { get; set; } = null!;

        public string ApptId { get; set; } = null!;

        public string? PhyId { get; set; }

        public string? PatientId { get; set; }

        public string? BookedBy { get; set; }

        public DateTime? NxtVisitDt { get; set; }

        public double? Hight { get; set; }

        public double? Weight { get; set; }

        public string? BpId { get; set; }

        public string? DiagId { get; set; }

        public string? MedicId { get; set; }

        public string? AllergyId { get; set; }

        public virtual Allergy? Allergy { get; set; }

        public virtual Appoinment Appt { get; set; } = null!;

        public virtual Master? BookedByNavigation { get; set; }

        public virtual BloodPerssureType? Bp { get; set; }

        public virtual Diagnosis? Diag { get; set; }

        public virtual Medication? Medic { get; set; }

        public virtual Master? Patient { get; set; }

        public virtual Master? Phy { get; set; }
    }


}
