﻿using System;
using System.Collections.Generic;

namespace HMS_MVC.Models
{
    public partial class BlockedUser
    {
        public string Username { get; set; } = null!;

        public DateTime BlockedTime { get; set; }

        public virtual Master UsernameNavigation { get; set; } = null!;
    }
}


