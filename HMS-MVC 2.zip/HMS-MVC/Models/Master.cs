﻿
using System;
using System.Collections.Generic;

namespace HMS_MVC.Models
{
    public partial class Master
    {
        public string MstrId { get; set; } = null!;

        public string? Name { get; set; }

        public string? Password { get; set; }

        public DateOnly? Dob { get; set; }

        public string? Email { get; set; }

        public int? RoleId { get; set; }

        public string? DisezCatId { get; set; }

        public bool? IsActive { get; set; }

        public string Username { get; set; } = null!;

        public virtual ICollection<Appoinment> AppoinmentNurses { get; set; } = new List<Appoinment>();

        public virtual ICollection<Appoinment> AppoinmentPatients { get; set; } = new List<Appoinment>();

        public virtual ICollection<Appoinment> AppoinmentPhies { get; set; } = new List<Appoinment>();

        public virtual BlockedUser? BlockedUser { get; set; }

        public virtual DiseaseCategory? DisezCat { get; set; }

        public virtual ICollection<PatientVisit> PatientVisitBookedByNavigations { get; set; } = new List<PatientVisit>();

        public virtual ICollection<PatientVisit> PatientVisitPatients { get; set; } = new List<PatientVisit>();

        public virtual ICollection<PatientVisit> PatientVisitPhies { get; set; } = new List<PatientVisit>();

        public virtual Role? Role { get; set; }
    }

}

    
