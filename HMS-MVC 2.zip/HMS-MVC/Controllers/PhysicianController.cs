﻿using Azure;
using HMS_MVC.DTO;
using HMS_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;

namespace HMS_MVC.Controllers
{
    public class PhysicianController : Controller
    {
        private readonly HttpClient _httpClient;
        public PhysicianController()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("http://localhost:5091/api/");
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreatePatientVisit(PatientVisitDTO patientVisit)
        {
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync("PatientVisit", patientVisit);
            if(response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Patient Visit created Successfully";
                return View("Index");
            }
            else
            {
                TempData["Message"] = "Something Went Wrong";
                return View("Index");
            }
            
        }

        public async Task<IActionResult> CreatePatientVisit()
        {
            HttpResponseMessage response = await _httpClient.GetAsync($"PatientVisit/GetDiagnosisForDsz/{HttpContext.Session.GetString("DiseaseCatId")}");
            HttpResponseMessage response1 = await _httpClient.GetAsync($"PatientVisit/GetAppointmentIDsForPhy/{HttpContext.Session.GetString("MstrId")}");
            HttpResponseMessage response2 = await _httpClient.GetAsync($"PatientVisit/GetBloodPressureTyp");
            HttpResponseMessage response3 = await _httpClient.GetAsync($"PatientVisit/GetAllergyTypForDigCtg/{HttpContext.Session.GetString("DiseaseCatId")}");
            if (response1.IsSuccessStatusCode || response2.IsSuccessStatusCode || response.IsSuccessStatusCode || response3.IsSuccessStatusCode)
            {
                Console.WriteLine(response3.StatusCode.ToString());
                string responseData1 = await response.Content.ReadAsStringAsync();
                List<DiagonsisDTO> dropdownApt = JsonConvert.DeserializeObject<List<DiagonsisDTO>>(responseData1);
                ViewBag.DropdownDataDig = dropdownApt;
                
                string responseData = await response1.Content.ReadAsStringAsync();
                List<string> AptIDs = JsonConvert.DeserializeObject<List<string>>(responseData);
                ViewBag.DropdownDataAptID = AptIDs;
               
                string responseData2 = await response2.Content.ReadAsStringAsync();
                List<BloodPressureDTO> ByTYps = JsonConvert.DeserializeObject<List<BloodPressureDTO>>(responseData2);
                ViewBag.DropdownDataBpTyp = ByTYps;

                string responseData3 = await response3.Content.ReadAsStringAsync();
                Console.WriteLine(responseData3);
                List<AllergyDTO> AlgTyps = JsonConvert.DeserializeObject<List<AllergyDTO>>(responseData3);
                ViewBag.DropdownDataAlgTyp = AlgTyps;
                foreach (var a in AlgTyps)
                {
                    Console.WriteLine(a.AllergyId + " " + a.AllergyNm);
                }


            }
            else
            {
                Console.WriteLine("sas");
                ViewBag.DropdownData = new List<string>();
                ViewBag.DropdownDataApt = new List<DiagonsisDTO>();
                ViewBag.DropdownDataBpTyp = new List<BloodPressureDTO>();

            }

            return View();
        }
        public async Task<JsonResult>  GetSecondDropDownOptions(string DiagId)
        {
            HttpResponseMessage response = await _httpClient.GetAsync($"PatientVisit/GetMedicineForDigCtg/{DiagId}");
            List<SelectListItem> MedDropdownData = new List<SelectListItem>();
            if (response.IsSuccessStatusCode)
            {
                string responseData = await response.Content.ReadAsStringAsync();
                List<MedicationDTO> dropdownDataMed = JsonConvert.DeserializeObject<List<MedicationDTO>>(responseData);
                foreach (var md in dropdownDataMed)
                {
                    MedDropdownData.Add(new SelectListItem { Text = md.MedicNm, Value = md.MedicId });
                }
            }
            return Json(MedDropdownData);
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}
