﻿using HMS_MVC.DTO;
using HMS_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace HMS_MVC.Controllers
{
    public class PatientController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<HomeController> _logger;
        public IActionResult Index()
        {
            return View();
        }
        public PatientController(ILogger<HomeController> logger)
        {

            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("http://localhost:5091/api/");
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> ViewDetails()
        {
            if (HttpContext.Session.GetString("DiseaseCatId") == null || HttpContext.Session.GetString("MstrId") == null)
            {
                TempData["Message"] = "Something Went Wrong";
                return RedirectToAction("Index", "Home");
            }
            HttpResponseMessage response = await _httpClient.GetAsync($"Patient/{HttpContext.Session.GetString("MstrId")}/PersonalDetails");
            if (response.IsSuccessStatusCode)
            {
                string responseData = await response.Content.ReadAsStringAsync();
                //List<Master> Details = JsonConvert.DeserializeObject<List<Master>>(responseData);

                //return View(responseData);
                return Content(responseData, "text/plain");
            }
            else
            {
                return Content("Error");
            }
        }

        [HttpGet]
        public async Task<IActionResult> DownloadDetails()
        {
            if (HttpContext.Session.GetString("DiseaseCatId") == null || HttpContext.Session.GetString("MstrId") == null)
            {
                TempData["Message"] = "Something Went Wrong";
                return RedirectToAction("Index", "Home");
            }
            HttpResponseMessage response = await _httpClient.GetAsync($"Patient/{HttpContext.Session.GetString("MstrId")}/DownloadDetails");
            if (response.IsSuccessStatusCode)
            {
                var fileContent = await response.Content.ReadAsByteArrayAsync();
                var contentDisposition = response.Content.Headers.ContentDisposition;
                var fileName = contentDisposition?.FileName ?? "PatientDetails.csv";
                return File(fileContent, "text/csv", fileName);

                //byte[] fileBytes = await response.Content.ReadAsByteArrayAsync();
                //return File(fileBytes, "text/csv", "PatientDetails.csv");

                //string responseData = await response.Content.ReadAsStringAsync();
                //List<Master> Details = JsonConvert.DeserializeObject<List<Master>>(responseData);
                
                //return View(responseData);
            }
            else
            {
                return Content("Error");
            }



        }

        [HttpGet]
        public async Task<IActionResult> ViewVisitHistory()
        {
            if (HttpContext.Session.GetString("DiseaseCatId") == null || HttpContext.Session.GetString("MstrId") == null)
            {
                TempData["Message"] = "Something Went Wrong";
                return RedirectToAction("Index", "Home");
            }

            HttpResponseMessage response = await _httpClient.GetAsync($"Patient/{HttpContext.Session.GetString("MstrId")}/VisitHistory");
            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                var Aptresponse = response.Content.ReadAsStringAsync().Result;
                IEnumerable<AppointmentDetailsDTO> Details = JsonConvert.DeserializeObject<IEnumerable<AppointmentDetailsDTO>>(Aptresponse);

                return View(Details);
            }
            else
            {
                return Content("Error");
            }

        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }

    }
}
