﻿using HMS_MVC.DTO;
using HMS_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace HMS_MVC.Controllers
{
    public class InboxController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<HomeController> _logger;

        public InboxController(ILogger<HomeController> logger)
        {

            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("http://localhost:5091/api/");
            _logger = logger;
        }
        //public IActionResult Index()
        //{
        //    return View();
        //}

        [HttpGet]
        public async Task<IActionResult> ViewNurseInbox()
        {
            if (HttpContext.Session.GetString("DiseaseCatId") == null || HttpContext.Session.GetString("MstrId") == null)
            {
                TempData["Message"] = "Something Went Wrong";
                return RedirectToAction("Index", "Home");
            }
            HttpResponseMessage response = await _httpClient.GetAsync($"Inbox/NurseInbox/{HttpContext.Session.GetString("MstrId")}");
            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                var Aptresponse = response.Content.ReadAsStringAsync().Result;
                IEnumerable<AppointmentDetailsDTO> Details = JsonConvert.DeserializeObject<IEnumerable<AppointmentDetailsDTO>>(Aptresponse);

                return View(Details);
            }
            else
            {
                return Content("Error");
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewPhyInbox()
        {
            if (HttpContext.Session.GetString("DiseaseCatId") == null || HttpContext.Session.GetString("MstrId") == null)
            {
                TempData["Message"] = "Something Went Wrong";
                return RedirectToAction("Index", "Home");
            }
            HttpResponseMessage response = await _httpClient.GetAsync($"Inbox/PhyInbox/{HttpContext.Session.GetString("MstrId")}");
            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                var Aptresponse = response.Content.ReadAsStringAsync().Result;
                IEnumerable<AppointmentDetailsDTO> Details = JsonConvert.DeserializeObject<IEnumerable<AppointmentDetailsDTO>>(Aptresponse);

                return View(Details);
            }
            else
            {
                return Content("Error");
            }
        }
    }
}
