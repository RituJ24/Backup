﻿using Microsoft.AspNetCore.Mvc;

namespace HMS_MVC.Controllers
{
    public class NurseController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}
