﻿using Microsoft.AspNetCore.Mvc;
using HMS_MVC.Models;
using HMS_MVC.DTO;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
namespace HMS_MVC.Controllers
{
    public class AdminController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<HomeController> _logger;

        public IActionResult Index()
        {
            if (TempData.ContainsKey("RegistrationSuccessMessage"))
            {
                ViewBag.RegistrationSuccessMessage = TempData["RegistrationSuccessMessage"];
            }
            return View();
        }
        public AdminController(ILogger<HomeController> logger)
        {

            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("http://localhost:5091/api/");
            _logger = logger;
        }
        [HttpGet]
        public async Task<IActionResult> ViewMaster()
        {

            HttpResponseMessage response = await _httpClient.GetAsync("Admins");
            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                var MasterResponse = response.Content.ReadAsStringAsync().Result;
                IEnumerable<MasterDetails> Details = JsonConvert.DeserializeObject<IEnumerable<MasterDetails>>(MasterResponse);

                return View(Details);
            }
            else
            {
                return Content("Error");
            }

        }
        [HttpPost]
        public async Task<IActionResult> RegisterNurse(MasterDTO nurse)
        {
            HttpResponseMessage response1 = await _httpClient.GetAsync($"Admins/CheckUserNameExist?username={nurse.Username}");
            if (response1.IsSuccessStatusCode)
            {
                TempData["Message"] = "Username enetred already exits";
                return RedirectToAction();
            }

            HttpResponseMessage response = await _httpClient.PostAsJsonAsync("Admins/RegisterNurse", nurse);

            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                TempData["RegistrationSuccessMessage"] = "Registration successful!";
                return RedirectToAction("Index");
            }
            else
            {
                return Content("Error");
            }

        }
        [HttpPost]
        public async Task<IActionResult> RegisterPhysician(MasterDTO phy)
        {
            HttpResponseMessage response1 = await _httpClient.GetAsync($"Admins/CheckUserNameExist?username={phy.Username}");
            if (response1.IsSuccessStatusCode)
            {
                TempData["Message"] = "Username alredy exists";
                return RedirectToAction();
            }
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync("Admins/RegisterPhysician", phy);
            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                TempData["RegistrationSuccessMessage"] = "Registration successful!";
                return RedirectToAction("Index");
            }
            else
            {
                return Content("Error");
            }
        }
        [HttpGet]
        public async Task<IActionResult> RegisterNurse()
        {
            HttpResponseMessage response = await _httpClient.GetAsync("Patient/GetDiseases");
            if (response.IsSuccessStatusCode)
            {
                // Parse the response and extract the data
                string responseData = await response.Content.ReadAsStringAsync();
                List<DiseaseCategory> dropdownDisease = JsonConvert.DeserializeObject<List<DiseaseCategory>>(responseData);
                ViewBag.DropdownDiseases = dropdownDisease;

            }
            else
            {
                ViewBag.DropdownDiseases = new List<DiseaseCategory>();
            }
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> RegisterPhysician()
        {
            HttpResponseMessage response = await _httpClient.GetAsync("Patient/GetDiseases");
            if (response.IsSuccessStatusCode)
            {
                // Parse the response and extract the data
                string responseData = await response.Content.ReadAsStringAsync();
                List<DiseaseCategory> dropdownDisease = JsonConvert.DeserializeObject<List<DiseaseCategory>>(responseData);
                ViewBag.DropdownDiseases = dropdownDisease;

            }
            else
            {
                ViewBag.DropdownDiseases = new List<DiseaseCategory>();
            }
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> RemoveMaster(string MstrId)
        {
            HttpResponseMessage response = await _httpClient.DeleteAsync($"Admins/RemoveMaster?masterid={MstrId}");
            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Removed Successfully";
                return RedirectToAction("ViewMaster");
            }
            else if(response.StatusCode == System.Net.HttpStatusCode.BadRequest)
            {
                TempData["Message"] = "This id has pending appointmnets cant be removed";
                return RedirectToAction("ViewMaster");
            }
            else
            {
                TempData["Message"] = "Something Went Wron";
                return RedirectToAction("Index", "Home");
            }
        }

    }
}


