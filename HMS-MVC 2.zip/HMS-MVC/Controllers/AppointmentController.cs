﻿using Microsoft.AspNetCore.Mvc;
using HMS_MVC.Models;
using Newtonsoft.Json;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc.Rendering;
using HMS_MVC.DTO;
namespace HMS_MVC.Controllers
{
    public class AppointmentController : Controller
    {
        private readonly HttpClient _httpClient;

        public IActionResult Index()
        {
            return View();
        }
        //sasasaa
        public AppointmentController()
        {   
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("http://localhost:5091/api/");
        }
        public async Task<IActionResult> BookApt()
        {
            if (HttpContext.Session.GetString("DiseaseCatId") == null || HttpContext.Session.GetString("MstrId") == null)
            {
                TempData["Message"] = "Something Went Wrong";
                return RedirectToAction("Index", "Home");
            }
            HttpResponseMessage response = await _httpClient.GetAsync($"Appointment/GetNursesForDscCtg/{HttpContext.Session.GetString("DiseaseCatId")}");

            if (response.IsSuccessStatusCode)
            {
                // Parse the response and extract the data
                string responseData = await response.Content.ReadAsStringAsync();
                List<Master> dropdownData = JsonConvert.DeserializeObject<List<Master>>(responseData);
                ViewBag.DropdownData = dropdownData;
            }
            else
            {
                ViewBag.DropdownData = new List<Master>();
            }
            return View();
        }
        public async Task<IActionResult> ScheduleApt()
        {
            if (HttpContext.Session.GetString("DiseaseCatId") == null || HttpContext.Session.GetString("MstrId") == null)
            {
                TempData["Message"] = "Something Went Wrong";
                return RedirectToAction("Index", "Home");
            }
            HttpResponseMessage response = await _httpClient.GetAsync($"Appointment/GetPhysicianForDscCtg/{HttpContext.Session.GetString("DiseaseCatId")}");
            HttpResponseMessage response1 = await _httpClient.GetAsync($"Appointment/GetAppointmentForNurse/{HttpContext.Session.GetString("MstrId")}");

            if (response.IsSuccessStatusCode && response1.IsSuccessStatusCode)
            {
                string responseData = await response.Content.ReadAsStringAsync();
                List<Master> dropdownData = JsonConvert.DeserializeObject<List<Master>>(responseData);
                ViewBag.DropdownDataPhy = SelectMastersCategory(dropdownData);
                string responseData1 = await response1.Content.ReadAsStringAsync();
                List<Appoinment> dropdownApt = JsonConvert.DeserializeObject<List<Appoinment>>(responseData1);
                ViewBag.DropdownDataApt = dropdownApt;
            }
            else
            {
                ViewBag.DropdownData = new List<Master>(); 
                ViewBag.DropdownDataApt = new List<Appoinment>();
            }

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ScheduleApt(Appoinment apt)
        {
            if (!ModelState.IsValid)
            {
                TempData["Message"] = "Please Enter correct details";
                return RedirectToAction();
            }
            HttpResponseMessage response = await _httpClient.PutAsJsonAsync("Appointment", apt);
            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Appointment Scheduled Successfully";
                return RedirectToAction();
            }
            else
            {
                TempData["Message"] = "Something went wrong";
                return RedirectToAction("Index", "Home");
            }

        }
        [HttpPost]
        public async Task<IActionResult> BookApt(BookAptDTO apt)
        {
            if (!ModelState.IsValid)
            {
                TempData["Message"] = "Please Enter correct details";
                return RedirectToAction();
            }

            apt.PatientId = HttpContext.Session.GetString("MstrId");
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync("Appointment", apt);
            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Appointment Booked Successfully";
                return RedirectToAction("Index", "Patient");
            }
            else
            {
                TempData["Message"] = "Something went wrong";
                return RedirectToAction("Index","Home");
            }

        }

        public List<SelectListItem> SelectMastersCategory(List<Master>? masters)
        {
            List<SelectListItem> items = new List<SelectListItem>();
            foreach(var master in masters)
            {
                items.Add(new SelectListItem { Text = master.Name, Value = master.MstrId });
            }
            return items;
        }


        public List<SelectListItem> SelectAppointmentCategory(List<Appoinment>? apts)
        {
            List<SelectListItem> items = new List<SelectListItem>();
            foreach (var apt in apts)
            {
                //items.Add(new SelectListItem { Text = $"{apt.ApptId} ------------------ {apt.ApptDt}", Value = apt.ApptId });
                items.Add(new SelectListItem { Text = apt.ApptId, Value = apt.ApptId });
            }
            return items;
        }
    }
}
