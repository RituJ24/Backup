﻿using Microsoft.AspNetCore.Mvc;
using HMS_MVC.DTO;
using HMS_MVC.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq.Expressions;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using HMS_MVC.Services;
using LoggerModule;
using EmailModule;
using Microsoft.DotNet.MSIdentity.Shared;
namespace HMS_MVC.Controllers
{
    public class LoginController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly LoggerModule.ILogger mylogger;
        public LoginController()
        {
            mylogger = new FileLogger();
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("http://localhost:5091/api/");
        }
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult ForgetPassword()
        {
            return View();
        }
        public IActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> ForgetPassword(string Username)
        {
            if (!ModelState.IsValid)
            {
                TempData["Message"] = "Please fill correct details";
                return View();
            }
            HttpResponseMessage response = await _httpClient.GetAsync($"Login/CheckUserNameExist?username={Username}");
            if (!response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Username enetred is Incorrect";
                return View();
            }
            response = await _httpClient.GetAsync($"Login/ForgetPasswordDetails?username={Username}");
            if (response.IsSuccessStatusCode)
            {
                string jsonResponse = await response.Content.ReadAsStringAsync();
                Console.WriteLine(jsonResponse);
                JObject responseObject = JObject.Parse(jsonResponse);
                // Access the properties of the JObject
                string name = responseObject["name"]?.ToString();
                string password = responseObject["password"]?.ToString();
                SendEmail.ForgetPassword(name, password);
                TempData["Message"] = "Forget Password Mail is Sent to You";
                return RedirectToAction("Index", "Home");
            }
            else
            {
                TempData["Message"] = "Something Went Wrong";
                return View();
            }
        }



        [HttpPost]
        public async Task<ActionResult>  ChangePassword(ChangePasswordDTO newusrDetail)
        {
            HttpResponseMessage response = await _httpClient.GetAsync($"Login/CheckUserNameExist?username={newusrDetail.Username}");
            if (!response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Username enetred is Incorrect";
                return View();
            }
            response = await _httpClient.GetAsync($"Login/CheckUserPassword?username={newusrDetail.Username}&password={newusrDetail.OldPassword}");
            if (response.IsSuccessStatusCode)
            {
               
                response = await _httpClient.PostAsJsonAsync("Login/UpdatePassword", newusrDetail);
                TempData["Message"] = "Password Changed Succesfully";
                return RedirectToAction("Index", "Home");
            }
            else
            {
                TempData["Message"] = "Credentials Entered are Incorrect";
                return View();
            }
            
        }


        [HttpPost]
        public async Task<ActionResult> Login(LoginDTO usr)
        {
            HttpResponseMessage response = await _httpClient.GetAsync($"Login/CheckUserNameExist?username={usr.Username}");
            if (!response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Username enetred is Incorrect";
                return View();
            }

            response = await _httpClient.GetAsync($"Login/CheckUserInBlockLst?username={usr.Username}");
            if(response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Please try again after sometime";
                return View();
            }
            int attempts = HttpContext.Session.GetInt32(usr.Username) ?? 0;
            if (attempts >= 3)
            {
                TempData["Message"] = "Please try again after sometime";
                await _httpClient.GetAsync($"Login/BlockUser?username={usr.Username}");
                HttpContext.Session.Remove(usr.Username);
                return View();
            }
            response = await _httpClient.GetAsync($"Login/CheckUserPassword?username={usr.Username}&password={usr.Password}");
            if (response.IsSuccessStatusCode)
            {
                LoggerManager.WriteLog(mylogger, $"[Login Status : Success] [Username : {usr.Username} Password : {usr.Password}] ");
                response = await _httpClient.GetAsync($"Login/GetMaster?username={usr.Username}&password={usr.Password}");
                string responseData = await response.Content.ReadAsStringAsync();
                Master master = JsonConvert.DeserializeObject<Master>(responseData);
                HttpContext.Session.SetString("MstrId", master.MstrId);
                HttpContext.Session.SetString("MstrName", master.Name);
                //string Master = JsonConvert.SerializeObject(master);
                //HttpContext.Session.SetString("Master", Master);
                if (master.DisezCatId != null)
                {
                    HttpContext.Session.SetString("DiseaseCatId", master.DisezCatId);
                }
                if(master.RoleId == 1)
                {
                    return RedirectToAction("Index", "Physician");
                }
                else if (master.RoleId == 2 )
                {
                    return RedirectToAction("Index", "Patient");
                }
                else if(master.RoleId == 3)
                {
                    return RedirectToAction("Index", "Nurse");
                }
                else
                {
                    return RedirectToAction("Index", "Admin");
                }
               
            }
            else if( response.StatusCode == System.Net.HttpStatusCode.NotFound )
            {

                TempData["Message"] = "Credentials Entered are Incorrect";
                LoggerManager.WriteLog(mylogger, $"[Login Status : Failed ] [Username : {usr.Username} Password : {usr.Password}] ");
                attempts++;
                HttpContext.Session.SetInt32(usr.Username, attempts);
                return View();
            }
            else
            {
                TempData["Message"] = "Something Went Wrong";
                return View();
            }

            return RedirectToAction("Index", "Home");
        }
        //public IActionResult RegisterPatient()
        //{
        //    return View();
        //}
        public async Task<IActionResult> RegisterPatient()
        {
            HttpResponseMessage response = await _httpClient.GetAsync("Patient/GetDiseases");
            //HttpResponseMessage response = await _httpClient.GetAsync($"Appointment/GetNursesForDscCtg/DISCAT-1");

            //if (response.IsSuccessStatusCode)
            //{
            //    Parse the response and extract the data
            //    string responseData = await response.Content.ReadAsStringAsync();
            //    List<Master> dropdownData = JsonConvert.DeserializeObject<List<Master>>(responseData);
            //    ViewBag.DropdownData = dropdownData;
            //}
            //else
            //{
            //    ViewBag.DropdownData = new List<Master>();
            //}
            if (response.IsSuccessStatusCode)
            {
                // Parse the response and extract the data
                string responseData = await response.Content.ReadAsStringAsync();
                List<DiseaseCategory> dropdownDisease = JsonConvert.DeserializeObject<List<DiseaseCategory>>(responseData);
                ViewBag.DropdownDiseases = dropdownDisease;

            }
            else
            {
                ViewBag.DropdownDiseases = new List<DiseaseCategory>();
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RegisterPatient(MasterDTO patient)
        {

            HttpResponseMessage response1 = await _httpClient.GetAsync($"Patient/CheckUserNameExist?username={patient.Username}");
            if (response1.IsSuccessStatusCode)
            {
                TempData["Message"] = "Username entered is already exists";
                return RedirectToAction();
            }
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync("Patient/RegisterPatient", patient);
            Console.WriteLine(response.StatusCode);
            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Registration successful!";
                return RedirectToAction("Index", "Home");
            }
            else
            {
                TempData["Message"] = "Registration Failed! Something went wrong!";
                return View();
            }

        }

    }
}
