﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace HMS_MVC.DTO
{
    public class PatientVisitDTO
    {
        [Required]
        public string? ApptId { get; set; }
        public string? PhyId { get; set; }

        public string? PatientId { get; set; }

        public string? BookedBy { get; set; }

        public DateTime? NxtVisitDt { get; set; }

        public double? Hight { get; set; }

        public double? Weight { get; set; }

        public string? BpId { get; set; }

        public string? DiagId { get; set; }

       
        public string? MedicId { get; set; }

        public string? AllergyId { get; set; }
    }
}
