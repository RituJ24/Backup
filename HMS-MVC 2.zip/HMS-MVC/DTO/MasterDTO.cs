﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace HMS_MVC.DTO
{
    public record MasterDTO
    {
        [Required(ErrorMessage = "Name is required")]
        public string? Name { get; set; }
        //[PasswordPropertyText]
        [Required]
        //[CustomPasswordValidation(ErrorMessage = "Password must conatins atleast one uppercase, one lowercase one numeric character...")]
        [RegularExpression("^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])[a-zA-Z0-9]{5,15}$", ErrorMessage = "Password must conatins atleast one uppercase, one lowercase one numeric character.")]
        public string? Password { get; set; }
        [Required]
        public DateOnly? Dob { get; set; }
        [Required]
        public string? Email { get; set; }
        public int? RoleId { get; set; }
        [Required]
        public string? DisezCatId { get; set; }
        public bool? IsActive { get; set; }
        [Required]
        public string? Username { get; set; }
    }
}
