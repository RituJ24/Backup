﻿namespace HMS_MVC.DTO
{
    public class AppointmentDetailsDTO
    {
        public string? PatientID { get; set; }
        public string? PatientName { get; set; }
        public string? AppointmentID { get; set; }
        public string? NurseName { get; set; }
        public DateOnly? AptDate { get; set; }
        public string? PhyName { get; set; }
    }
}
