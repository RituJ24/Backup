﻿using HMS_MVC.Models;
using System.ComponentModel.DataAnnotations;

namespace HMS_MVC.DTO
{
    public record BookAptDTO
    {
        public string? PatientId { get; set; }
        [Required]
        public string? NurseId { get; set; }
        [Required]
        [CustomHireDate(ErrorMessage = "BookAppointment Date must be greater than or equal to Today's Date")]
        public DateOnly? ApptDt { get; set; }
    }
    public class CustomHireDate : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            DateOnly dateTime = (DateOnly)value;
            return dateTime >= DateOnly.FromDateTime(DateTime.Now);
        }
    }

}


