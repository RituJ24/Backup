﻿namespace HMS_MVC.DTO
{
    public record MasterDetails
    {
        public string? MasterId { get; set; }
        public string? MasterName { get; set; }
    }
}
