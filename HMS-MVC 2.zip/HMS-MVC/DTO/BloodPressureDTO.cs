﻿namespace HMS_MVC.DTO
{
    public record BloodPressureDTO
    {
        public string BpId { get; set; }

        public string? BpType { get; set; }

    }
}
