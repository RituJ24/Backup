﻿using System.ComponentModel.DataAnnotations;

namespace HMS_MVC.DTO
{
    public record ScheduleAptDTO
    {
        [Required]
        public string? ApptId { get; set; }

        [Required]
        public string? PhyId { get; set; }
    }
}
