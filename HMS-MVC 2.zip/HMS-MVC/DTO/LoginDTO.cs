﻿using System.ComponentModel.DataAnnotations;

namespace HMS_MVC.DTO
{
    public record LoginDTO
    {
        [Required]
        public string? Username { get; set; }

        [Required]
        public string? Password { get; set; }
    }
}
