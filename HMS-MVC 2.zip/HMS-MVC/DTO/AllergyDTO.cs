﻿namespace HMS_MVC.DTO
{
    public record AllergyDTO
    {
        public string AllergyId { get; set; }

        public string? AllergyNm { get; set; }
    }
}
