﻿using Microsoft.Extensions.Logging;
using LoggerModule;
namespace HMS_MVC.Services
{
    public class LoggerManager
    {
        public static void WriteLog(LoggerModule.ILogger logger, string mesasge)
        {
            logger.Log(mesasge);
        }
    }
}