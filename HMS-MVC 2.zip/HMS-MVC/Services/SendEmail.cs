﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using HMS_MVC.Models;

namespace EmailModule
{
    public class SendEmail
    {
        public static void AppointmentEmail(string? PatientName, DateOnly? AptDate, string? PhysicianName, string? NurseName)
        {

            string? Subject = "Patient Appointment Schedule...";
            string? EmailAddress = "9420132083.sk@gmail.com";
            StringBuilder body = new StringBuilder("Hello ");
            body.AppendLine(PatientName + ",");
            body.Append("\nYour appointment has been scheduled on ");
            body.Append(AptDate);
            body.Append(" with Dr. ");
            body.Append(PhysicianName);
            body.AppendLine("\n\nThanks & Regards,");
            body.Append(NurseName);
            //Console.WriteLine(body.ToString()); 
            Email.SendEmail(Subject, EmailAddress, body.ToString());


        }
        public static void PatientVisitEmail(PatientVisit patientvisit)
        {
            string? Subject = "Visit Details - EPrescription...";
            string? EmailAddress = "9420132083.sk@gmail.com";
            StringBuilder body = new StringBuilder("Hello " + patientvisit.Patient.Name + ",\n\n");
            body.AppendLine("Patient ID : " + patientvisit.PatientId + ",");
            body.AppendLine("Full Name : " + patientvisit.Patient.Name + ",");
            body.AppendLine("Date Of Birth : " + patientvisit.Patient.Dob + ",");
            body.AppendLine("Visit ID : " + patientvisit.VisitId + ",");
            body.AppendLine("Height : " + patientvisit.Hight + ",");
            body.AppendLine("Weight During Visit : " + patientvisit.Weight + ",");
            body.AppendLine("Diagnosis : " + patientvisit.Diag.DiagDesc + ",");
            body.AppendLine("Medication Suggested : " + patientvisit.Medic.MedicNm + ",");
            if (patientvisit.AllergyId == null)
            {
                body.AppendLine("Allergies : No Allergy Found,");
            }
            else
            {
                body.AppendLine("Allergies : " + patientvisit.Allergy.AllergyNm + ",");
            }
            body.AppendLine("Next Visit Suggested On : " + (patientvisit.NxtVisitDt == null ? "No Visit Needed" : patientvisit.NxtVisitDt));
            body.AppendLine("\n\nThanks & Regards,");
            body.Append(patientvisit.Phy.Name);
            //Console.WriteLine(body.ToString());
            Email.SendEmail(Subject, EmailAddress, body.ToString());


        }
        public static void ForgetPassword(string? PatientName, string Password)
        {
            string? Subject = "Forget Password...";
            string? EmailAddress = "9420132083.sk@gmail.com";
            StringBuilder body = new StringBuilder();
            body.AppendLine("Hi " + PatientName + ",\n\n");
            body.AppendLine("Your password is : " + Password);
            body.AppendLine("\n\nThanks & Regards,");
            body.Append("HMS");
            //Console.WriteLine(body.ToString());
            //try
            //{
            Console.WriteLine(body.ToString());
            //Email.SendEmail(Subject, EmailAddress, body.ToString());
            //}
            //catch (SmtpException e)
            //{
            //   return
            //}
            //catch (FailedToSendException e)
            //{
            //    OutputMessage.ErrorMessage(e.Message);
            //}
        }
    }
}
